#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
قنوات نشر النشرة اليومية.
================================
تُستدعى بعد اكتمال التقرير واجتياز بوابة المخاطر:
  1) صندوق محلي: نسخة مؤرشفة في published/<التاريخ>/ (دائمًا).
  2) تيليجرام: رسالة ملخّص + ملف HTML مرفق (إن وُجد رمز البوت ومعرّف القناة).
  3) خطاف ويب عام (إن وُجد PUBLISH_WEBHOOK_URL).

الإعدادات (متغيرات بيئة):
  PUBLISH_TELEGRAM_BOT_TOKEN  — رمز البوت من @BotFather
  PUBLISH_TELEGRAM_CHAT_ID    — معرّف القناة/المجموعة (مثل -1001234567890 أو @channel)
  PUBLISH_WEBHOOK_URL         — أي رابط POST (اختياري)

الاستخدام المباشر للاختبار:
  python3 publish_hooks.py jobs/crypto_daily_2026-09-05/04_daily_brief.md --dry-run
"""
import argparse, json, os, re, shutil, sys, urllib.request, uuid
from pathlib import Path

BASE = Path(__file__).resolve().parent
OUTBOX = BASE / "published"
TG_API = "https://api.telegram.org/bot{token}/{method}"


# ------------------------------------------------------------- الملخّص
def build_summary(md: str) -> str:
    """يستخرج من النشرة: العنوان، مستوى المخاطرة، وخلاصة 3 أسطر."""
    title = next((l.lstrip("# ").strip() for l in md.splitlines() if l.startswith("# ")), "النشرة اليومية")
    date = next((l.replace("*", "").strip() for l in md.splitlines()
                 if re.search(r"\d{4}-\d{2}-\d{2}|يناير|فبراير|مارس|أبريل|مايو|يونيو|يوليو|أغسطس|سبتمبر|أكتوبر|نوفمبر|ديسمبر", l)
                 and l.strip().startswith("**")), "")
    risk = next((l.replace("*", "").strip() for l in md.splitlines() if "مستوى المخاطرة" in l), "")

    summary = []
    grab = False
    for l in md.splitlines():
        if "الخلاصة في 3 أسطر" in l:
            grab = True
            continue
        if grab:
            if l.startswith("##") or l.startswith("---"):
                break
            s = l.strip()
            if re.match(r"^\d+\.", s):
                summary.append(re.sub(r"^\d+\.\s*", "• ", s.replace("**", "")))
    summary_txt = "\n".join(summary[:3])

    return (
        f"📊 {title}\n{date}\n{risk}\n\n"
        f"{summary_txt}\n\n"
        f"⚠️ تحليل تعليمي وليس نصيحة استثمارية.\n"
        f"📎 المرفق: النشرة الكاملة (صفحة HTML)."
    )[:1000]  # حد تسمية التيليجرام 1024 حرف


# ------------------------------------------------------------- أدوات HTTP
def _post_json(url: str, payload: dict, timeout=30):
    req = urllib.request.Request(
        url, data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def _multipart(url: str, fields: dict, files: dict, timeout=60):
    """إرسال multipart/form-data (لمرفقات تيليجرام). files: {name: (filename, bytes, ctype)}."""
    boundary = "----agent" + uuid.uuid4().hex
    body = b""
    for k, v in fields.items():
        body += f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n".encode("utf-8")
    for name, (fname, data, ctype) in files.items():
        body += (f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"; "
                 f"filename=\"{fname}\"\r\nContent-Type: {ctype}\r\n\r\n").encode("utf-8")
        body += data + b"\r\n"
    body += f"--{boundary}--\r\n".encode("utf-8")
    req = urllib.request.Request(url, data=body,
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


# ------------------------------------------------------------- القنوات
def publish_telegram(md_path: Path, html_path: Path, dry_run: bool) -> str:
    token = os.environ.get("PUBLISH_TELEGRAM_BOT_TOKEN")
    chat = os.environ.get("PUBLISH_TELEGRAM_CHAT_ID")
    if not (token and chat):
        return "telegram: تخطّي (لم تُضبط PUBLISH_TELEGRAM_BOT_TOKEN / CHAT_ID)"
    caption = build_summary(md_path.read_text(encoding="utf-8"))
    if dry_run:
        return f"telegram(dry-run): كان سيُرسل إلى {chat} — {len(caption)} حرفًا + مرفق {html_path.name}"
    try:
        data = _multipart(
            TG_API.format(token=token, method="sendDocument"),
            fields={"chat_id": chat, "caption": caption},
            files={"document": (html_path.name, html_path.read_bytes(), "text/html")})
        if data.get("ok"):
            return f"telegram: ✔ أُرسلت النشرة إلى {chat} (message_id={data['result']['message_id']})"
        return f"telegram: ⚠ رفض الخادم: {data.get('description')}"
    except Exception as e:
        return f"telegram: ⚠ فشل الإرسال ({e}) — النشرة محفوظة في الصندوق المحلي."


def publish_webhook(html_path: Path, md_path: Path, dry_run: bool) -> str:
    url = os.environ.get("PUBLISH_WEBHOOK_URL")
    if not url:
        return "webhook: تخطّي (لا يوجد PUBLISH_WEBHOOK_URL)"
    payload = {"type": "crypto_daily", "html": str(html_path), "markdown": str(md_path)}
    if dry_run:
        return f"webhook(dry-run): كان سيُرسل POST إلى {url}"
    try:
        _post_json(url, payload)
        return "webhook: ✔ تم الاستدعاء."
    except Exception as e:
        return f"webhook: ⚠ فشل ({e})"


def deliver(md_path: Path, html_path: Path, date_str: str, dry_run: bool = False):
    """ينسخ للصندوق المحلي ثم يدفع لكل القنوات المضبوطة. يعيد قائمة نتائج."""
    results = []
    ddir = OUTBOX / date_str
    ddir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(md_path, ddir / md_path.name)
    shutil.copy2(html_path, ddir / html_path.name)
    results.append(f"outbox: ✔ مؤرشف في {ddir.relative_to(BASE)}")
    results.append(publish_telegram(md_path, html_path, dry_run))
    results.append(publish_webhook(html_path, md_path, dry_run))
    return results


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("brief", help="مسار 04_daily_brief.md")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--date", default=None)
    args = ap.parse_args()
    md = Path(args.brief)
    html = md.with_suffix(".html")
    if not html.exists():
        sys.exit("شغّل render_brief.py أولًا لتوليد صفحة HTML.")
    date = args.date or re.search(r"(\d{4}-\d{2}-\d{2})", str(md))
    date = date if isinstance(date, str) else (date.group(1) if date else "undated")
    for line in deliver(md, html, date, dry_run=args.dry_run):
        print(line)
