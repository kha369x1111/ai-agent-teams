#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
المشغّل اليومي الآلي لنشرة العملات الرقمية.
================================================
1) ينشئ مجلد مهمة بتاريخ اليوم ويضع طلب التحليل.
2) يشغّل فريق الوكلاء (وضع --api تلقائي عبر LLM، أو وضع الطيار المساعد).
3) بعد اعتماد بوابة المخاطر والتقرير، يحوّل النشرة إلى HTML للنشر.
4) سجل تشغيل في logs/ — وفي وضع --api يُسلّم التقرير إلى خطاف النشر (اختياري).

الاستخدام:
    python3 daily_crypto.py                 # تشغيل اليوم (api إن وُجد المفتاح)
    python3 daily_crypto.py --date 2026-09-05
    python3 daily_crypto.py --manual        # وضع الطيار المساعد (بلا API)

متغيرات النشر الاختيارية:
    PUBLISH_WEBHOOK_URL  — رابط يُستدعى بعد الاكتمال (يرسل مسار النشرة/HTML)
"""
import argparse, datetime, json, os, subprocess, sys
from pathlib import Path

import publish_hooks

BASE = Path(__file__).resolve().parent
JOBS = BASE / "jobs"
LOGS = BASE / "logs"


def log(msg):
    print(f"[{datetime.datetime.now():%H:%M:%S}] {msg}")


def make_request(job: Path, date_str: str):
    (job).mkdir(parents=True, exist_ok=True)
    req = job / "00_request.md"
    if not req.exists():
        req.write_text(
            f"# طلب التحليل اليومي\n\n"
            f"**التاريخ:** {date_str} · **نوع التقرير:** نشرة يومية للمتابعين\n"
            f"**الأصول:** BTC (أساسي)، ETH (ثانوي)\n"
            f"**الإطار الزمني:** يومي مع نظرة للأسبوع الجاري\n"
            f"**الهدف:** تغطية صباحية: أين السوق، المحركات، السيناريوهات، ومتى نحذر.\n",
            encoding="utf-8")
        log("أُنشئ طلب التحليل.")
    else:
        log("طلب التحليل موجود مسبقًا.")


def run_team(job: Path, use_api: bool) -> bool:
    cmd = [sys.executable, str(BASE / "crypto_orchestrator.py"), str(job)]
    if use_api:
        cmd.append("--api")
    log("تشغيل فريق الوكلاء: " + ("وضع API تلقائي" if use_api else "وضع الطيار المساعد"))
    r = subprocess.run(cmd, capture_output=True, text=True)
    sys.stdout.write(r.stdout)
    if r.returncode != 0:
        log("✖ توقف الفريق — راجع مخرجات البوابة أعلاه.")
        return False
    done = (job / "status.json").exists() and json.loads(
        (job / "status.json").read_text(encoding="utf-8")).get("phase") == "done"
    return done


def render(job: Path) -> Path:
    brief = job / "04_daily_brief.md"
    if not brief.exists():
        raise FileNotFoundError("النشرة غير موجودة")
    out = subprocess.run([sys.executable, str(BASE / "render_brief.py"), str(brief)],
                         capture_output=True, text=True)
    sys.stdout.write(out.stdout)
    return brief.with_suffix(".html")


def publish(html_path: Path, date_str: str, dry_run: bool):
    """أرشفة محلية + دفع لكل قنوات النشر المضبوطة (تيليجرام/خطاف)."""
    for line in publish_hooks.deliver(html_path.with_suffix(".md"), html_path, date_str, dry_run):
        log(line)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--date", default=None)
    ap.add_argument("--manual", action="store_true",
                    help="وضع الطيار المساعد (بلا LLM API)")
    ap.add_argument("--dry-run", action="store_true",
                    help="ينشئ كل شيء ولا يرسل لتيليجرام/الخطاف فعلًا")
    args = ap.parse_args()

    date_str = args.date or datetime.date.today().isoformat()
    job = JOBS / f"crypto_daily_{date_str}"
    LOGS.mkdir(exist_ok=True)
    log(f"=== نشرة العملات اليومية — {date_str} ===")
    make_request(job, date_str)

    use_api = (not args.manual) and bool(os.environ.get("LLM_API_KEY") or os.environ.get("OPENAI_API_KEY"))
    ok = run_team(job, use_api)
    if not ok:
        if not use_api:
            log("وضع يدوي: أكمل ملفات الوكلاء المطلوبة ثم أعد التشغيل لإكمال الأتمتة والنشر.")
        return 1

    html_path = render(job)
    log(f"✔ صفحة النشر جاهزة: {html_path}")
    publish(html_path, date_str, args.dry_run)
    log("اكتملت الدورية.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
