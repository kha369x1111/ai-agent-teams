#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
محرك فريق تحليل العملات الرقمية (يومي)
=====================================
طلب → جمع بيانات → 3 محللين بالتوازي (ماكرو/فني/معنويات)
      → بوابة مدير المخاطر (إلزامية) → التقرير اليومي.

قاعدة ذهبية: هذا فريق تحليل، ليس فريق توصيات استثمار.
أي مخرج بلا «إخلاء مسؤولية» أو بلا سيناريوهات واحتمالات ترفضه البوابة.

التشغيل:
    python3 crypto_orchestrator.py jobs/btc_daily_2026-09-05
    python3 crypto_orchestrator.py jobs/btc_daily_2026-09-05 --api
"""
import argparse, json, os, sys, urllib.request
from datetime import datetime
from pathlib import Path

BASE = Path(__file__).resolve().parent
CRYPTO_AGENTS = BASE / "agents" / "crypto"

# (الملف, العناصر الإلزامية, بطاقة الوكيل)
PHASES = {
    "brief": {"label": "طلب التحليل", "next": "data", "files": [
        ("00_request.md", ["# طلب", "الأصول"], None)]},
    "data": {"label": "جمع البيانات", "next": "analysis", "files": [
        ("01_data.md", ["http", "المصدر"], "c02_data_feed.md")]},
    "analysis": {"label": "التحليل (3 محللين بالتوازي)", "next": "risk", "files": [
        ("02a_macro.md", ["الفيدرالي", "http"], "c03_macro_analyst.md"),
        ("02b_technical.md", ["دعم", "مقاومة"], "c04_technical_analyst.md"),
        ("02c_sentiment.md", ["خوف", "طمع"], "c05_sentiment_analyst.md")]},
    "risk": {"label": "بوابة مدير المخاطر", "next": "report", "files": [
        ("03_risk.md", ["إخلاء مسؤولية", "سيناريو", "وقف"], "c06_risk_manager.md")]},
    "report": {"label": "التقرير اليومي", "next": None, "files": [
        ("04_daily_brief.md", ["إخلاء مسؤولية", "مستوى المخاطرة"], "c07_report_writer.md")]},
}


def ts():
    return datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S")


def load_status(job):
    p = job / "status.json"
    if p.exists():
        return json.loads(p.read_text(encoding="utf-8"))
    return {"phase": "brief", "history": [], "created": ts()}


def save_status(job, status):
    (job / "status.json").write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")


def context_for(job, phase, fname):
    parts = []

    def add(name, f):
        p = job / f
        if p.exists():
            parts.append(f"===== {name} | {f} =====\n" + p.read_text(encoding="utf-8"))

    add("الطلب", "00_request.md")
    if phase in ("analysis", "risk", "report"):
        add("البيانات المعتمدة", "01_data.md")
    if phase == "analysis":
        pass  # كل محلل يرى البيانات فقط (لا يرى زملاءه → استقلالية)
    if phase in ("risk", "report"):
        add("تحليل الماكرو", "02a_macro.md")
        add("التحليل الفني", "02b_technical.md")
        add("تحليل المعنويات", "02c_sentiment.md")
    if phase == "report":
        add("تقرير المخاطر المعتمد", "03_risk.md")
    return "\n\n".join(parts)


def llm_generate(system, user):
    base = (os.environ.get("LLM_BASE_URL") or "https://api.openai.com/v1").rstrip("/")
    key = os.environ.get("LLM_API_KEY") or os.environ.get("OPENAI_API_KEY")
    model = os.environ.get("LLM_MODEL", "gpt-4o-mini")
    if not key:
        sys.exit("✖ وضع --api يتطلب مفتاحًا في LLM_API_KEY")
    payload = {"model": model, "temperature": 0.4,
               "messages": [{"role": "system", "content": system},
                            {"role": "user", "content": user}]}
    req = urllib.request.Request(base + "/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=600) as r:
        return json.loads(r.read().decode("utf-8"))["choices"][0]["message"]["content"]


def run(job_dir, use_api):
    if use_api and not (os.environ.get("LLM_API_KEY") or os.environ.get("OPENAI_API_KEY")):
        sys.exit("✖ وضع --api يتطلب مفتاحًا في متغير LLM_API_KEY")
    job = Path(job_dir)
    job.mkdir(parents=True, exist_ok=True)
    status = load_status(job)
    print("=" * 64)
    print("  فريق تحليل العملات الرقمية — محرك التنسيق")
    print(f"  المهمة: {job.name}")
    print("=" * 64)

    for _ in range(20):
        phase = status["phase"]
        if phase == "done":
            print("\n🎉 التقرير اليومي جاهز في 04_daily_brief.md (مع إخلاء المسؤولية).")
            return 0
        spec = PHASES[phase]
        pending = []   # ملفات ناقصة/مرفوضة تُعيّن للوكلاء
        all_passed = True
        for fname, markers, agent_file in spec["files"]:
            fpath = job / fname
            if not fpath.exists():
                pending.append((fname, agent_file))
                all_passed = False
                continue
            text = fpath.read_text(encoding="utf-8")
            missing = [m for m in markers if m not in text]
            if missing:
                print(f"\n⚠ بوابة «{spec['label']}» رفضت {fname} — ينقصه: {missing}")
                pending.append((fname, agent_file))
                all_passed = False

        if all_passed:
            files = ", ".join(f for f, _, _ in spec["files"])
            status["history"].append({"phase": phase, "state": "passed",
                                      "files": files, "ts": ts()})
            if spec["next"] is None:
                status["phase"] = "done"
                save_status(job, status)
                print(f"✔ {spec['label']}: معتمد.")
                print("\n🎉 التقرير اليومي جاهز في 04_daily_brief.md.")
                return 0
            status["phase"] = spec["next"]
            save_status(job, status)
            print(f"✔ {spec['label']}: معتمد — التالي: {PHASES[status['phase']]['label']}.")
            continue

        # تعيين الملفات الناقصة (في analysis تُعيّن الثلاثة دفعة واحدة = توازٍ)
        for fname, agent_file in pending:
            status["history"].append({"phase": phase, "state": "assigned",
                                      "file": fname, "ts": ts()})
            card = ""
            if agent_file:
                card = (CRYPTO_AGENTS / agent_file).read_text(encoding="utf-8")
            prompt = (f"أنت وكيل في فريق تحليل عملات رقمية. بطاقة دورك:\n\n{card}\n\n"
                      f"━━━━ السياق ━━━━\n{context_for(job, phase, fname)}\n\n"
                      f"أنتج الملف {fname} كاملًا بالعربية (Markdown). "
                      f"كل رقم بمصدر. تذكّر: تحليل لا توصية شراء/بيع مؤكدة.")
            if use_api and agent_file:
                print(f"\n🤖 الوكيل يعمل على {fname} ...")
                (job / fname).write_text(llm_generate(card, prompt), encoding="utf-8")
            else:
                print(f"\n▶ {spec['label']} → المطلوب: {fname}")
                print("-" * 60)
                print(prompt if not agent_file else
                      f"بطاقة الوكيل: agents/crypto/{agent_file}\n(شغّل الوكيل بالبطاقة أعلاه وأنتج {fname})")
                print("-" * 60)
        save_status(job, status)
        if not use_api:
            print("\n⏸ أنتج الملف/الملفات الناقصة ثم أعد التشغيل — البوابة ستتحقق.")
            return 0
    return 1


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="محرك فريق تحليل العملات الرقمية")
    ap.add_argument("job")
    ap.add_argument("--api", action="store_true")
    args = ap.parse_args()
    sys.exit(run(args.job, args.api))
