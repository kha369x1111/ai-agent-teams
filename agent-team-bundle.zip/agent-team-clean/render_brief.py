#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
يحوّل النشرة اليومية (04_daily_brief.md) إلى صفحة HTML عربية RTL مستقلة
جاهزة للنشر/الإرسال — بلا أي اعتماد خارجي (أنماط وخطوط مضمنة).

الاستخدام: python3 render_brief.py jobs/<المهمة>/04_daily_brief.md
"""
import html, re, sys
from pathlib import Path


def inline(t):
    t = html.escape(t)
    t = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", t)
    t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
    t = re.sub(r"(https?://[^\s<)]+)", r'<a href="\1">\1</a>', t)
    return t


def md_to_html(md):
    lines = md.splitlines()
    out, i = [], 0
    while i < len(lines):
        ln = lines[i]
        s = ln.strip()
        if not s:
            i += 1
            continue
        # جدول markdown
        if s.startswith("|") and i + 1 < len(lines) and set(lines[i + 1].replace("|", "").replace(" ", "").replace(":", "").replace("-", "")) == set():
            header = [c.strip() for c in s.strip("|").split("|")]
            i += 2
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")])
                i += 1
            t = ['<table><thead><tr>'] + [f"<th>{inline(c)}</th>" for c in header] + ["</tr></thead><tbody>"]
            for r in rows:
                t.append("<tr>" + "".join(f"<td>{inline(c)}</td>" for c in r) + "</tr>")
            t.append("</tbody></table>")
            out.append("".join(t))
            continue
        if s.startswith(">"):
            quote = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                quote.append(lines[i].strip().lstrip(">").strip())
                i += 1
            out.append("<blockquote>" + inline(" ".join(quote)) + "</blockquote>")
            continue
        if s in ("---", "***"):
            out.append("<hr>")
            i += 1
            continue
        m = re.match(r"^(#{1,4})\s+(.*)$", s)
        if m:
            lvl = len(m.group(1))
            out.append(f"<h{lvl}>{inline(m.group(2))}</h{lvl}>")
            i += 1
            continue
        if re.match(r"^[-*]\s+", s):
            items = []
            while i < len(lines) and re.match(r"^[-*]\s+", lines[i].strip()):
                items.append("<li>" + inline(re.sub(r"^[-*]\s+", "", lines[i].strip())) + "</li>")
                i += 1
            out.append("<ul>" + "".join(items) + "</ul>")
            continue
        if re.match(r"^\d+\.\s+", s):
            items = []
            while i < len(lines) and re.match(r"^\d+\.\s+", lines[i].strip()):
                items.append("<li>" + inline(re.sub(r"^\d+\.\s+", "", lines[i].strip())) + "</li>")
                i += 1
            out.append("<ol>" + "".join(items) + "</ol>")
            continue
        out.append(f"<p>{inline(s)}</p>")
        i += 1
    return "\n".join(out)


CSS = """
:root{--ink:#241a12;--muted:#6b5d4f;--bg:#f7f1e7;--card:#fffdf8;--brand:#6f4e37;--accent:#d9743b;--line:#e6dccb;}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font-family:'Segoe UI','Tahoma','Noto Naskh Arabic',sans-serif;line-height:1.9;-webkit-font-smoothing:antialiased;}
.wrap{max-width:720px;margin:0 auto;padding:24px 18px 60px;}
.brand{text-align:center;padding:18px 0 6px;color:var(--brand);font-weight:800;letter-spacing:.5px;}
h1{font-size:1.7rem;color:var(--brand);border-bottom:3px solid var(--accent);padding-bottom:10px;}
h2{font-size:1.3rem;color:var(--brand);margin-top:34px;border-right:5px solid var(--accent);padding-right:12px;}
h3{font-size:1.08rem;color:var(--muted);margin-top:22px;}
p{margin:12px 0;}
strong{color:var(--brand);}
a{color:var(--accent);word-break:break-all;}
code{background:#f0e7d7;padding:1px 6px;border-radius:6px;font-size:.9em;direction:ltr;display:inline-block;}
blockquote{background:#fff3e6;border-right:5px solid var(--accent);margin:16px 0;padding:12px 16px;border-radius:10px;color:#5c4632;font-weight:600;}
hr{border:none;border-top:1px dashed var(--line);margin:26px 0;}
table{width:100%;border-collapse:collapse;background:var(--card);border-radius:12px;overflow:hidden;margin:16px 0;box-shadow:0 1px 6px rgba(111,78,55,.08);font-size:.93rem;}
th{background:var(--brand);color:#fff;padding:10px;text-align:right;}
td{padding:10px;border-top:1px solid var(--line);vertical-align:top;}
tr:nth-child(even) td{background:#fbf6ec;}
ul,ol{padding-right:22px;}
li{margin:6px 0;}
.foot{margin-top:34px;text-align:center;color:var(--muted);font-size:.85rem;}
@media(max-width:520px){h1{font-size:1.4rem}table{font-size:.82rem}th,td{padding:7px}}
"""


def convert(md_path: Path):
    md = md_path.read_text(encoding="utf-8")
    title = next((l.lstrip("# ").strip() for l in md.splitlines() if l.startswith("#")), "النشرة اليومية")
    body = md_to_html(md)
    out = f"""<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{html.escape(title)}</title>
<style>{CSS}</style>
</head>
<body>
<div class="wrap">
<div class="brand">☕ فريق تحليل العملات الرقمية</div>
{body}
<div class="foot">نشرة مولّدة آليًا عبر نظام الوكلاء — تحليل تعليمي وليس نصيحة استثمارية.</div>
</div>
</body>
</html>"""
    dst = md_path.with_suffix(".html")
    dst.write_text(out, encoding="utf-8")
    return dst


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("الاستخدام: python3 render_brief.py <مسار ملف النشرة .md>")
    print("أُنشئ:", convert(Path(sys.argv[1])))
