#!/usr/bin/env bash
# مُثبِّت الجدولة اليومية لنشرة العملات الرقمية.
# يضيف مهمة cron تعمل كل يوم في الساعة 7:00 صباحًا بتوقيت الجهاز.
#
# الاستخدام:
#   LLM_API_KEY=sk-xxxx bash install_daily_cron.sh
#
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="$(command -v python3)"
LOG="$DIR/logs/cron.log"
mkdir -p "$DIR/logs"

# سطر الكرون: كل يوم 7 صباحًا — أضف مفتاح LLM إن أردت التشغيل التلقائي بالكامل
ENV=""
if [[ -n "${LLM_API_KEY:-}" ]]; then
  ENV="LLM_API_KEY=$LLM_API_KEY "
fi
JOB="$ENV $PY $DIR/daily_crypto.py >> $LOG 2>&1"

# احذف أي سطر قديم لمشغّلنا ثم أضِف الجديد
( crontab -l 2>/dev/null | grep -v 'daily_crypto.py' ; echo "0 7 * * * $JOB" ) | crontab -

echo "✔ أُضيفت المهمة المجدولة (يوميًا 07:00):"
crontab -l | grep 'daily_crypto.py'
echo
echo "السجل: $LOG"
echo "للإلغاء: crontab -l | grep -v daily_crypto.py | crontab -"
echo
echo "ملاحظة: للتشغيل التلقائي بالكامل يجب أن يكون LLM_API_KEY متاحًا؛"
echo "بدونه يعمل المشغّل في وضع الطيار المساعد ويتوقف عند أول ملف ناقص."
