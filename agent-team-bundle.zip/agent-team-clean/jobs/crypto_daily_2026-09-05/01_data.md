# خلاصة البيانات الموحدة — جلسة 2026-09-05

> ملاحظة مهمة: توجد فروق بين تغذيات الأسعار يومي 3–4 سبتمبر؛ النطاق مسجل كما هو
> ولا تُخفى الفروق (هذه تعليمة مدير المخاطر لاحقًا).

## Bitcoin (BTC)
| المؤشر | القيمة | وقت التقاط | المصدر |
|---|---|---|---|
| السعر الفوري | ~$81,240 (افتتاح 4 سبتمبر $81,271.92) | 4 سبتمبر صباحًا | Yahoo Finance |
| تغذية بديلة (مشتقات/تحليلات) | $76,000–$78,900 (3 سبتمبر $77,928) | 3 سبتمبر | Cryptonomist |
| أعلى سعر خلال 24س | ~$82,136 | 4 سبتمبر | CoinStats |
| تغيّر 24 ساعة | +5.05% إلى +5.26% | 4 سبتمبر | CoinStats/Yahoo |
| تغيّر 7 أيام | +1.24% إلى +1.28% | 4 سبتمبر | CoinStats |
| تغيّر 30 يومًا | ~+27% (من ~$63,900) | 4 سبتمبر | CoinStats/Fortune |
| قبل سنة | $110,773 (أي −28% سنويًا) | 4 سبتمبر | Fortune |
| القيمة السوقية | ~$1.63 تريليون | 4 سبتمبر | CoinStats |
| حجم 24س | ~$44.4 مليار | 4 سبتمبر | CoinStats |
| هيمنة BTC | 57.57% | 1 سبتمبر | CryptoRank |
| مؤشر الخوف والطمع | 64–65 «طمع» (بعد أن كان 78) | 4 سبتمبر | CoinStats |
| مراكز العقود الآجلة | 56.1% حسابات قصيرة (بيوع) | 4 سبتمبر | CoinStats |
| تدفقات ETF (30 يومًا) | ~$3.33 مليار؛ أكبر تدفق يومي في 9 أشهر | 4 سبتمبر | CoinStats/Yahoo |
| مشتريات مؤسسية | Strategy استأنفت الشراء بـ$370 مليون | 3 سبتمبر | Cryptonomist (نقلاً عن Bloomberg) |

### مؤشرات فنية (BTC، يومي — Cryptonomist 3 سبتمبر)
- RSI14 يومي: 66.69 (صاعد بلا تشبع شرائي).
- MACD يومي: خط MACD تحت خط الإشارة، هيستوجرام −195.86 (زخم يبرد).
- البيفوت: 77,693 | دعم S1: 77,203 | مقاومة R1: 78,419 | EMA200 على ساعة: 78,086.
- البولينجر العلوي: 86,381 | متوسط المدى اليومي (ATR): ~2,666 نقطة.

## Ethereum (ETH)
| المؤشر | القيمة | المصدر |
|---|---|---|
| السعر | ~$2,411–$2,453 (4 سبتمبر) | Fortune/CoinDCX |
| مستوى حاسم | فيبو 0.618 الأسبوعي $2,438 (إغلاق أسبوعي فوقه إيجابي) | CryptoRank |
| مقاومة | $2,500 ثم $2,550 (رُفض عندها)؛ إغلاق أسبوعي فوق 2,550 يفتح $3,000 | The Coin Republic |
| دعم | $2,438 ثم EMA20 $2,307 ثم $2,220 (Supertrend) ثم $2,000 | CryptoRank/CoinDCX |
| هدف سبتمبر | $2,600 (نطاق $2,164–$2,850) | CoinDCX |
| هيمنة ETH | 10.87% | CryptoRank |
| محفزات | 35 منتجًا/تطويرًا جديدًا على الشبكة تُناقش هذا الأسبوع | The Coin Republic |
| غاز الشبكة | 0.16 Gwei (نشاط منخفض) | CryptoRank |

## أحداث الجلسة (ماكرو)
- **الفيدرالي:** اجتماع أواخر سبتمبر؛ تصريحات المحافظ كريس وولر عن تثبيت محتمل للفائدة،
  لكن الأسواق تسعّر احتمال ~57% لرفع الفائدة بسبب الطاقة/التضخم. (CoinStats/Yahoo)
- **التوظيف:** تقرير وظائف أغسطس يُنتظر صدوره؛ رقم «مستقر ومعتدل» قد يدعم الأصول المخاطرة. (Yahoo)
- **جيوسياسة:** تصعيد عسكري أمريكي–إيراني مطلع الأسبوع (ضربات ورد بصواريخ/طائرات مسيّرة)
  ضغط النفط والأصول الخطرة في 2 سبتمبر (هبط BTC إلى ~$76,600 ثم تعافى). (Yahoo)

## قائمة المصادر
1. Yahoo Finance — Bitcoin and ethereum prices today, Sep 4 2026:
   https://finance.yahoo.com/personal-finance/investing/article/bitcoin-and-ethereum-prices-today-friday-september-4-2026-bitcoin-holding-above-81000-following-massive-etf-inflows-113751298.html
2. Yahoo Finance — Sep 2 2026 (التصعيد الإيراني):
   https://finance.yahoo.com/personal-finance/investing/article/bitcoin-and-ethereum-prices-today-wednesday-september-2-2026-crypto-prices-tumble-as-iran-war-reignites-112639522.html
3. Cryptonomist — BTC analysis Sep 3 2026:
   https://en.cryptonomist.ch/2026/09/03/bitcoin-price-today-analysis-bullish/
4. Fortune — BTC price Sep 4 2026: https://fortune.com/article/price-of-bitcoin-09-04-2026/
5. CoinStats — BTC news Sep 4 2026: https://coinstats.app/ai/a/latest-news-for-bitcoin
6. CoinDCX — ETH price prediction Sep 2026:
   https://coindcx.com/blog/price-predictions/ethereum-price-prediction/
7. CryptoRank — ETH September outlook:
   https://cryptorank.io/news/feed/bf7c2-ethereum-price-september-outlook-2026
8. The Coin Republic — ETH breaks 2500, Sep 4 2026:
   https://thecoinrepublic.com/2026/09/04/ethereum-price-breaks-2500-resistance-as-eth-community-weighs-35-new-products
