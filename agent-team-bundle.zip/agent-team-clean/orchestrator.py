#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
محرّك تنسيق فريق الوكلاء — إنتاج المحتوى الرقمي
================================================
ستة وكلاء متخصصون بقيادة وكيل تنسيق، يعملون عبر مراحل إلزامية
مع نقاط تحقق وحلقة مراجعة (كاتب ← محرر) حتى الاعتماد.

التشغيل:
    python3 orchestrator.py jobs/qahwetna_amman          # وضع الطيار المساعد (بلا مفتاح API)
    python3 orchestrator.py jobs/qahwetna_amman --api    # تنفيذ تلقائي عبر واجهة LLM متوافقة مع OpenAI

متغيرات البيئة لوضع --api:
    LLM_API_KEY   (أو OPENAI_API_KEY)
    LLM_BASE_URL  (افتراضي: https://api.openai.com/v1)
    LLM_MODEL     (افتراضي: gpt-4o-mini)
"""
import argparse, json, os, re, sys, urllib.request
from datetime import datetime
from pathlib import Path

BASE = Path(__file__).resolve().parent
AGENTS_DIR = BASE / "agents"

# ---------------------------------------------------------------- المراحل
PHASES = {
    "brief": {
        "agent_file": None, "label": "استقبال الموجز", "next": "strategy",
        "markers": ["# موجز", "الجمهور", "المنصات", "المخرجات", "نبرة"],
    },
    "strategy": {
        "agent_file": "02_strategist.md", "label": "الاستراتيجية", "next": "research",
        "markers": ["الفكرة المحورية", "أركان المحتوى", "التقويم", "KPIs"],
    },
    "research": {
        "agent_file": "03_researcher.md", "label": "البحث والحقائق", "next": "draft",
        "markers": ["http", "المصدر"],
    },
    "draft": {
        "agent_file": "04_creator.md", "label": "الكتابة (المسوّدة)", "next": "review",
        "markers": ["منشور", "ريلز", "مقال", "نشرة"],
    },
    "review": {
        "agent_file": "05_editor.md", "label": "المراجعة وضمان الجودة", "next": None,
        "markers": ["القرار"],
    },
    "package": {
        "agent_file": "06_distributor.md", "label": "التغليف والتوزيع", "next": "visual",
        "markers": ["تقويم النشر", "قائمة الفحص"],
    },
    "visual": {
        "agent_file": "07_visual_designer.md", "label": "التصميم البصري", "next": "ads",
        "markers": ["أبعاد", "كوفر"],
    },
    "ads": {
        "agent_file": "08_paid_ads.md", "label": "الإعلانات المدفوعة", "next": "platform",
        "markers": ["الميزانية", "جمهور", "إيقاف"],
    },
    "platform": {
        "agent_file": "09_ads_platform.md", "label": "بناء حملات المنصات", "next": "community",
        "markers": ["حملة", "نص الإعلان", "الميزانية"],
    },
    "community": {
        "agent_file": "10_community.md", "label": "التفاعل المجتمعي", "next": None,
        "markers": ["رد", "تصعيد", "تعليق"],
    },
}


def ts():
    return datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S")


def expected_file(phase, rnd):
    return {
        "brief": "00_brief.md",
        "strategy": "01_strategy.md",
        "research": "02_research.md",
        "draft": f"03_draft_r{rnd}.md",
        "review": f"04_review_r{rnd}.md",
        "package": "05_final_package.md",
        "visual": "06_visuals.md",
        "ads": "07_ads_plan.md",
        "platform": "08_ads_launch.md",
        "community": "09_community_playbook.md",
    }[phase]


# ---------------------------------------------------------------- الحالة
def load_status(job: Path):
    p = job / "status.json"
    if p.exists():
        return json.loads(p.read_text(encoding="utf-8"))
    return {"phase": "brief", "round": 1, "history": [], "created": ts()}


def save_status(job: Path, status):
    (job / "status.json").write_text(
        json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")


def record(status, phase, state, fname, note=""):
    status["history"].append(
        {"phase": phase, "state": state, "file": fname, "round": status["round"],
         "ts": ts(), "note": note})


# ---------------------------------------------------------------- التحقق
def validate(phase, text):
    """نقطة التحقق: يتأكد المحرك أن الملف يحمل العناصر الإلزامية قبل تمريره."""
    missing = [m for m in PHASES[phase]["markers"] if m not in text]
    if phase == "review" and not re.search(
            r"القرار[:：]\s*(اعتماد|تعديل|رفض|APPROVE|REVISE)", text, re.I):
        missing.append('سطر قرار صريح: «القرار: اعتماد» أو «القرار: تعديل»')
    if phase == "draft" and len(text) < 3000:
        missing.append("المسوّدة قصيرة جدًا — كل المخرجات المطلوبة؟")
    return missing


def verdict(text):
    m = re.search(r"القرار[:：]\s*(اعتماد|تعديل|رفض|APPROVE|REVISE)", text, re.I)
    if not m:
        return None
    v = m.group(1).lower()
    return {"اعتماد": "approve", "approve": "approve",
            "تعديل": "revise", "revise": "revise"}.get(v, "reject")


# ---------------------------------------------------------------- السياق
def context_for(phase, job: Path, rnd):
    parts = []

    def add(name, fname):
        p = job / fname
        if p.exists():
            parts.append(f"===== {name} | ملف: {fname} =====\n"
                         + p.read_text(encoding="utf-8"))

    add("الموجز المعتمد", "00_brief.md")
    add("الاستراتيجية المعتمدة", "01_strategy.md")
    add("ملف البحث المعتمد", "02_research.md")
    if phase == "draft" and rnd > 1:
        add("ملاحظات المراجعة السابقة (التزم بها حرفيًا)", f"04_review_r{rnd-1}.md")
    if phase == "review":
        add(f"المسوّدة قيد المراجعة (الجولة {rnd})", f"03_draft_r{rnd}.md")
    if phase == "package":
        add("المسوّدة المعتمدة نهائيًا", f"03_draft_r{rnd}.md")
        add("محضر المراجعة النهائية", f"04_review_r{rnd}.md")
    if phase in ("visual", "ads", "platform", "community"):
        add("حزمة النشر المعتمدة", "05_final_package.md")
        add("المسوّدة المعتمدة", f"03_draft_r{rnd}.md")
    if phase in ("ads", "platform"):
        add("ملف المرئيات المعتمد", "06_visuals.md")
    if phase == "platform":
        add("خطة الإعلانات المعتمدة", "07_ads_plan.md")
    return "\n\n".join(parts)


def build_prompt(phase, card, context, fname, rnd):
    return f"""أنت تعمل داخل فريق وكلاء لإنتاج المحتوى. بطاقة دورك:

{card}

━━━━━━━━ السياق المعتمد من المراحل السابقة ━━━━━━━━
{context}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

مهمتك الآن: أنتج الملف «{fname}» كاملًا بالعربية، بتنسيق Markdown.
- التزم بمعايير الإنجاز في بطاقة دورك وبالمبادئ الإلزامية في الاستراتيجية.
- لا تخترع إحصائيات: كل رقم يخرج من ملف البحث مع ذكر مصدره.
- إن كنت وكيل الكتابة في جولة تعديل، عالج كل ملاحظة في محضر المراجعة السابقة.
- اكتب المخرجات النهائية فقط (نص الملف)، دون شرح أو مقدمات.
"""


# ---------------------------------------------------------------- LLM
def llm_generate(system, user):
    base = (os.environ.get("LLM_BASE_URL") or "https://api.openai.com/v1").rstrip("/")
    key = os.environ.get("LLM_API_KEY") or os.environ.get("OPENAI_API_KEY")
    model = os.environ.get("LLM_MODEL", "gpt-4o-mini")
    if not key:
        sys.exit("✖ وضع --api يتطلب مفتاحًا في متغير LLM_API_KEY")
    payload = {"model": model, "temperature": 0.7,
               "messages": [
                   {"role": "system", "content": system or "أنت وكيل متخصص في فريق إنتاج محتوى عربي."},
                   {"role": "user", "content": user}]}
    req = urllib.request.Request(
        base + "/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=600) as r:
        data = json.loads(r.read().decode("utf-8"))
    return data["choices"][0]["message"]["content"]


# ---------------------------------------------------------------- العرض
def banner(job, status):
    print("=" * 64)
    print("  فرقة وكلاء إنتاج المحتوى — محرك التنسيق")
    print(f"  المهمة: {job.name}  |  المرحلة: {status['phase']}  |  الجولة: {status['round']}")
    print("=" * 64)


def print_task(phase, spec, fname, prompt):
    print(f"\n▶ المرحلة: {spec['label']}  →  الملف المطلوب: {fname}\n")
    if phase == "brief":
        print("الموجز غير موجود. ابدأ من القالب:")
        print(f"  cp briefs/template_brief.md {fname}")
        print("  ثم املأ الحقول وأعد تشغيل المحرك.")
        return
    print("تعليمات الوكيل (استخدمها كبرومبت نظام + مهمة):")
    print("-" * 64)
    print(prompt)
    print("-" * 64)
    print(f"\n⏸ أنتج الملف {fname} في مجلد المهمة، ثم أعد التشغيل — سيتحقق المحرك تلقائيًا.")


# ---------------------------------------------------------------- التشغيل
def run(job_dir, use_api):
    job = Path(job_dir)
    job.mkdir(parents=True, exist_ok=True)
    status = load_status(job)
    banner(job, status)

    for _ in range(30):
        phase = status["phase"]
        if phase == "done":
            print("\n🎉 المهمة مكتملة — الحزمة النهائية في 05_final_package.md وجاهزة للنشر.")
            return 0
        rnd = status["round"]
        spec = PHASES[phase]
        fname = expected_file(phase, rnd)
        fpath = job / fname

        if fpath.exists():
            text = fpath.read_text(encoding="utf-8")
            missing = validate(phase, text)
            if missing:
                print(f"\n⚠ بوابة «{spec['label']}» رفضت الملف {fname} — ينقصه:")
                for m in missing:
                    print(f"   - {m}")
                print("أصلح الملف ثم أعد التشغيل.")
                return 2
            record(status, phase, "passed", fname)
            if phase == "review":
                v = verdict(text)
                if v == "approve":
                    status["phase"] = "package"
                    print(f"✔ المراجعة (جولة {rnd}): اعتماد — ننتقل إلى التغليف.")
                elif v == "revise":
                    status["phase"] = "draft"
                    status["round"] = rnd + 1
                    print(f"↻ المراجعة (جولة {rnd}): تعديل مطلوب — جولة كتابة {rnd+1}.")
                else:
                    status["phase"] = "strategy"
                    print(f"✖ المراجعة (جولة {rnd}): رفض جوهري — العودة للاستراتيجية.")
            elif phase == "community":
                status["phase"] = "done"
                save_status(job, status)
                print("✔ التفاعل المجتمعي: معتمد.")
                print("\n🎉 المهمة مكتملة — المحتوى والمرئيات والإعلانات والتفاعل جاهزة بالكامل.")
                return 0
            else:
                status["phase"] = spec["next"]
                print(f"✔ {spec['label']}: معتمد — التالي: {PHASES[status['phase']]['label']}.")
            save_status(job, status)
            continue

        # الملف غير موجود: إطلاق الوكيل
        card = ""
        if spec["agent_file"]:
            card = (AGENTS_DIR / spec["agent_file"]).read_text(encoding="utf-8")
        prompt = build_prompt(phase, card, context_for(phase, job, rnd), fname, rnd)
        record(status, phase, "assigned", fname)
        save_status(job, status)

        if use_api and phase != "brief":
            print(f"\n🤖 الوكيل «{spec['label']}» يعمل على {fname} ...")
            result = llm_generate(card, prompt)
            fpath.write_text(result, encoding="utf-8")
            print(f"   كُتب {fname}.")
            continue
        print_task(phase, spec, fname, prompt)
        return 0

    print("✖ تجاوزنا الحد الأقصى من الجولات — راجع status.json")
    return 1


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="محرك تنسيق فريق وكلاء إنتاج المحتوى")
    ap.add_argument("job", help="مجلد المهمة، مثل jobs/qahwetna_amman")
    ap.add_argument("--api", action="store_true", help="تنفيذ تلقائي عبر LLM API")
    args = ap.parse_args()
    sys.exit(run(args.job, args.api))
